const express = require("express");
const users= require("./MOCK_DATA.json");
const app= express();
app.use(express.json());

const PORT= process.env.PORT || 3000;

app.get("/users", (req,res)=>{
    
    res.send(users);
});
app.get("/users/:id", (req,res)=>{
    const ids= Number(req.params.id);
    const user= users.find((user)=> user.id===ids);
    return res.json(user);
});

app.post("/create", (req,res)=>{
    const payload= req.body;
    
    console.log("user created successfully!!!");
});

app.listen(PORT ,()=>{
    console.log("server started at port : ",PORT);
});

